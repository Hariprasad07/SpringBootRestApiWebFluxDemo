package com.ssp.demo.repo;

import com.ssp.demo.entities.Advertiser;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface AdvertiserRespository extends R2dbcRepository<Advertiser, Long> {

    //@Query("select ad.pid,ad.seller_id,ad.name from as_advertiser ad")
    Flux<Advertiser> findAll();

    //@Query(value = "select pid from as_advertiser")
    Mono<Advertiser> findById(Long pid);
}
