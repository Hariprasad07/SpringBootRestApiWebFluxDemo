package com.ssp.demo.entities;


public class DazzlerDemo {

    private int dazzler_id;
    private String department;
    private String project;
}
