package com.ssp.demo.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;

import java.util.Date;

public class AdSize {

    @Id
    @Column("id")
    private int id;

    @Column("name")
    private String name;

    @Column("created_on")
    private Date created_on;

}
