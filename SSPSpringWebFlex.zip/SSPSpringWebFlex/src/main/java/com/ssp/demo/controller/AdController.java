package com.ssp.demo.controller;

import com.ssp.demo.entities.Advertiser;
import com.ssp.demo.service.AdvertiseService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/")
@AllArgsConstructor
public class AdController {

    @Autowired
    private AdvertiseService adSer;

    @GetMapping
    public Flux<Advertiser> findAll()
    {
        return adSer.findAllAd();
    }

    @GetMapping("/{pid}")
    public Mono<ResponseEntity<Advertiser>> getUserById(@PathVariable long pid){
        Mono<Advertiser> user = adSer.getAdById(pid);
        return user.map( u -> ResponseEntity.ok(u))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
}
