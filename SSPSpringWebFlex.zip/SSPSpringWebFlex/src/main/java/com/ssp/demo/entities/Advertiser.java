package com.ssp.demo.entities;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;


@org.springframework.data.relational.core.mapping.Table("as_advertiser")

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
@NoArgsConstructor
public class Advertiser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column("pid")
    private long pid;

    @Column("seller_id")
    @EqualsAndHashCode.Include
    private long seller_id;

    @Column("name")
    @EqualsAndHashCode.Include
    private String name;
}
