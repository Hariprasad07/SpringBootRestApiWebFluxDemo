package com.ssp.demo.service.impl;

import com.ssp.demo.entities.Advertiser;
import com.ssp.demo.repo.AdvertiserRespository;
import com.ssp.demo.service.AdvertiseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Transactional
@EnableJpaRepositories(basePackages = "com.ssp.demo.repo.AdvertiserRespository")
public class AdvertiseServiceImpl implements AdvertiseService {

    @Autowired
    private AdvertiserRespository adRepo;

    @Override
    public Mono<Advertiser> getAdById(long pid) {
        return adRepo.findById(pid);
    }

    @Override
    public Flux<Advertiser> findAllAd() {
        return adRepo.findAll();
    }

    @Override
    public Mono<Advertiser> createAd(Advertiser a) {
        return adRepo.save(a);
    }

    @Override
    public Mono<Advertiser> deleteAd(long pid) {
        return adRepo.findById(pid)
                .flatMap( exData -> adRepo.delete(exData)
                        .then(Mono.just(exData)));
    }

    @Override
    public Mono<Advertiser> updateAd(long pid, Advertiser ad) {
        return adRepo.findById(pid)
                .flatMap( u -> {
                   u.setPid(ad.getPid());
                   u.setSeller_id(ad.getSeller_id());
                   u.setName(ad.getName());
                   return adRepo.save(u);
                });
    }
}
