package com.ssp.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SspSpringWebFlexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SspSpringWebFlexApplication.class, args);
	}

}
