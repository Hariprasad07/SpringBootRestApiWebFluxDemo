package com.ssp.demo.service;

import com.ssp.demo.entities.Advertiser;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface AdvertiseService {
    Mono<Advertiser> getAdById(long pid);
    Flux<Advertiser> findAllAd();

    Mono<Advertiser> createAd(Advertiser a);

    Mono<Advertiser> deleteAd(long pid);

    Mono<Advertiser> updateAd(long pid, Advertiser ad);
}
